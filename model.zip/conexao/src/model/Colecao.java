package model;
import java.util.ArrayList;

public abstract class Colecao {
	
	private ArrayList<Musica> musicas; 
	private String fotoDaCapaUrl;
	private long tempoStreaming;
	private String nome;
	
		
	Colecao(ArrayList<Musica> musicas, String fotoDaCapaUrl, long tempoStreaming, String nome) {
		this.musicas = musicas;
		this.fotoDaCapaUrl = fotoDaCapaUrl;
		this.tempoStreaming = tempoStreaming;
		this.nome = nome;
	}

	//getters
	public ArrayList<Musica> getMusicas() {
		return musicas;
	}
	
	public String getFotoDaCapaURL() {
		return fotoDaCapaUrl;
	}
	
	public String getNome() {
		return nome;
	}
	
	public long getTempoStreaming() {
		return tempoStreaming;
	}

	//setters
	public void setMusicas(ArrayList<Musica> musicas) {
		this.musicas = musicas;
	}
	
	public void setFotoDaCapaURL(String fotoDaCapaURL) {
		fotoDaCapaUrl = fotoDaCapaURL;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setTempoStreaming(long tempoStreaming) {
		this.tempoStreaming = tempoStreaming;
	}
	
	
	
}
